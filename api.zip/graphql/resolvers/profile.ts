import { generateResolvers } from '../resolver';

export default generateResolvers('Profile', ['patient']);
