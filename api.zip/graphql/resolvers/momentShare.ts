import { generateResolvers } from '../resolver';

export default generateResolvers('MomentShare', ['moment', 'clinicians']);
