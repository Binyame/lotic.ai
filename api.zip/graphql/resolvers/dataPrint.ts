import { generateResolvers } from '../resolver';

export default generateResolvers('DataPrint', ['patient']);
