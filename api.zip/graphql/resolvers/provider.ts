import { generateResolvers } from '../resolver';

export default generateResolvers('Provider', ['patient']);
