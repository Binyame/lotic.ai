import { generateResolvers } from '../resolver';

export default generateResolvers('MomentPrompt', ['prompt', 'moment']);
