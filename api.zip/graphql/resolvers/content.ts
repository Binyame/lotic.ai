import { generateResolvers } from '../resolver';

export default generateResolvers('Content', []);
