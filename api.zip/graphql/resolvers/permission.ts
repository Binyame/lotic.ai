import { generateResolvers } from '../resolver';

export default generateResolvers('Permission', ['patient']);
