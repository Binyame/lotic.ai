import { generateResolvers } from '../resolver';

export default generateResolvers('SignalQuestion', ['review', 'assessment']);
