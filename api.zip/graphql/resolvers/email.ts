import { generateResolvers } from '../resolver';

export default generateResolvers('Email', ['patient']);
