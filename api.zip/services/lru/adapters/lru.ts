import LRU from 'lru-cache';
const LRUAdapter = LRU;
export default LRUAdapter;
