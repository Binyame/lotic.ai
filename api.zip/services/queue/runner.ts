import Queue from './index';

Queue.startJobs();
