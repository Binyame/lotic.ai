import patient from './patient';
import clinician from './clinician';
import lotic from './lotic';
import github from './github';

export default {
  patient,
  clinician,
  lotic,
  github,
};
